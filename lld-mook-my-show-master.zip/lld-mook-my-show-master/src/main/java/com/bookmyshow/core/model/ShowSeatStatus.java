package com.bookmyshow.core.model;

public enum ShowSeatStatus {
    AVAILABLE,
    BOOKED,
    TEMPORARILY_BLOCKED,
}
