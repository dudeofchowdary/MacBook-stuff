package com.bookmyshow.core.model;

public enum TransactionStatus {
    NEW,
    PAYMENT_MADE,
    FAILED,
    PROCESSING,
}
