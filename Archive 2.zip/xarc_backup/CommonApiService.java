package com.comcast.xarc.vcmts.rlcm.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.comcast.xarc.vcmts.config.client.ConfigManagerRestClient;
import com.comcast.xarc.vcmts.config.service.OperationsService;
import com.comcast.xarc.vcmts.config.service.RlcmService;
import com.comcast.xarc.vcmts.rlcm.client.RlcmSSHClient;
import com.comcast.xarc.vcmts.rlcm.utils.PingStatus;
import com.comcast.xarc.vcmts.rlcm.utils.RlcmCommandConstants;
import com.comcast.xarc.vcmts.rlcm.utils.RlcmUtils;
import com.comcast.xarc.vcmts.rlcm.utils.SSHFunctionality;
import com.comcast.xarc.vcmts.rlcm.utils.TelemetryUtilClass;
import com.comcast.xarc.vcmts.rlcm.utils.TestExecutionParameters;
import com.comcast.xarc.vcmts.rlcm.utils.UpgradeStatus;
import com.google.gson.Gson;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.json.JSONArray;

@Service("commonApiService")
@Scope(value = "prototype")
public class CommonApiService extends TestExecutionParameters {
	private final static Logger logger = LoggerFactory.getLogger(CommonApiService.class);

	@Resource(name = "endToEndProps")
	private Properties endToEndProperties;

	@Resource(name = "rlcmProps")
	private Properties rlcmProperties;

	@Autowired
	@Qualifier("rlcmSSHClient")
	RlcmSSHClient rlcmSSHClient;

	String[] replaceKeyList = null;
	String[] replaceValueList = null;
	String[] replacePrometheusFilter = null;
	String outputFromPrometheus = "";
	public WebElement e;
	private static WebDriver driver;
	public static Gson gson = new Gson();
	private String rpdupgradepythonScriptName = "";
	private static Properties dataBaseProperties;
	private static String encryptedPassword;
	private static String userName;
	private static String url;
	private static String decryptedPassword;

	static {
		try {
			dataBaseProperties = new Properties();
			InputStream is = new FileInputStream(
					System.getProperty("rlcm.properties.dir") + "/" + "dbConnection.properties");
			if (is != null)
				dataBaseProperties.load(is);

		} catch (Exception e) {
			e.printStackTrace();
		}
		encryptedPassword = dataBaseProperties.getProperty("hibernate.connection.password");
		userName = dataBaseProperties.getProperty("hibernate.connection.username");
		url = dataBaseProperties.getProperty("hibernate.connection.url");
		decryptedPassword = RlcmUtils.decrypt(encryptedPassword);
	}

	/**
	 *
	 * queryPrometheusForServiceTelemetry API executes the Prometheus query for
	 * K_topics and retrieves the response
	 *
	 * @param inputJSON(vCMTSIP ,username ,password,Prometheus
	 *        URL,username,password,Query)
	 * @return (outputJSON-queryOutput ,log,errorlog,output,result (Success/Failure)
	 *         returnValue-which can be used/required for next step)
	 */
	public String sendPrometheusQuery(final String inputs) {
		JSONObject inputJsonObj = new JSONObject(inputs);
		logger.debug("Inside prometheus service");
		int totalWaitTime = 0;
		String RebootTime = "";
		Random random = new Random();
		String typeOfServer = "";
		String id = "";
		SSHFunctionality ssh = new SSHFunctionality();
		try {
			// Xi logic
			String vCMTSIP = inputJsonObj.getString("cmtsIp");
			String vCMTSUsername = inputJsonObj.getString("loginUserName");
			String vCMTSPassword = inputJsonObj.getString("loginPassword");
			if (inputJsonObj.has("branch_name") && (inputJsonObj.getString("branch_name").contains("xi")
					|| inputJsonObj.getString("branch_name").contains("pak"))) {
				typeOfServer = "xi";
				Calendar c = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("YYYY_MM_dd_hhmmss_SSS");
				String ddd = sdf.format(c.getTimeInMillis());
				id = inputJsonObj.getString("branch_name") + ddd;
				System.out.println("ssh id  " + id);
				vCMTSIP = vCMTSIP + "%" + "xi" + "%" + inputJsonObj.toString() + "%" + id;
			}
			String system_OS = System.getProperty("os.name");
			String matchOutputInPrometheus = "";
			String getDataFromPrometheus = "";
			String prometheusURLFromDropdown = "";
			String prometheusUrl = "";
			String prometheusMetric = "";
			String expectedOutput = "";
			String dataNeeded = "";
			String excludeSimRPDs = "";
			String inputValue = "";
			String inputKey = "";
			String prometheusFilter = "";
			int noOfIteration = 1;
			String siteName = "";
			String finalURL = "";
			// exclude namespace
			String excludeNamespace = "";
			if (inputJsonObj.has("EXCLUDE_NAMESPACE") && !inputJsonObj.getString("EXCLUDE_NAMESPACE").contains("NA")) {
				excludeNamespace = inputJsonObj.getString("EXCLUDE_NAMESPACE").replaceAll(",", "|");
			}

			// prometheusURLFromDropdown
			if (inputJsonObj.has("PrometheusURL") && !inputJsonObj.getString("PrometheusURL").contains("NA")) {
				prometheusURLFromDropdown = inputJsonObj.getString("PrometheusURL");
			}

			// excludeSimRPDs
			if (inputJsonObj.has("excludeSimRPDs") && !inputJsonObj.getString("excludeSimRPDs").contains("NA")) {
				excludeSimRPDs = inputJsonObj.getString("excludeSimRPDs");
			}

			// keyToBeReplaced
			if (inputJsonObj.has("inputKey") && !inputJsonObj.getString("inputKey").contains("NA")) {
				inputKey = inputJsonObj.getString("inputKey");
			}

			// filterParameters
			if (inputJsonObj.has("prometheusFilter") && !inputJsonObj.getString("prometheusFilter").contains("NA")) {
				prometheusFilter = inputJsonObj.getString("prometheusFilter");
			}

			// valueToBeReplaced
			if (inputJsonObj.has("inputValue") && !inputJsonObj.getString("inputValue").contains("NA")) {
				inputValue = inputJsonObj.getString("inputValue");
			}

			// prometheusMetric
			if (inputJsonObj.has("apiToBeCalled") && !inputJsonObj.getString("apiToBeCalled").contains("NA")) {
				prometheusMetric = inputJsonObj.getString("apiToBeCalled");
			}

			// dataToBeFetched
			if (inputJsonObj.has("getDataFromPrometheus")
					&& !inputJsonObj.getString("getDataFromPrometheus").contains("NA")) {
				getDataFromPrometheus = inputJsonObj.getString("getDataFromPrometheus");
			}

			// dataNeeded
			if (inputJsonObj.has("dataNeeded") && !inputJsonObj.getString("dataNeeded").contains("NA")) {
				dataNeeded = inputJsonObj.getString("dataNeeded");
			}

			// exclude RPD
			String excludeRPD = "";
			if (inputJsonObj.has("EXCLUDE_RPD") && !inputJsonObj.getString("EXCLUDE_RPD").contains("NA")) {
				excludeRPD = inputJsonObj.getString("EXCLUDE_RPD").replaceAll(", ", "|").replaceAll(",", "|");
			}

			if (inputJsonObj.has("matchOutputInPrometheus")
					&& !inputJsonObj.get("matchOutputInPrometheus").equals("NA")) {
				matchOutputInPrometheus = inputJsonObj.getString("matchOutputInPrometheus");
				log.add("MATCH THE DATA in the output : " + matchOutputInPrometheus);
			}
			// expected output from API -description
			if (inputJsonObj.has("expectedOutput") && !inputJsonObj.get("expectedOutput").equals("NA")) {
				expectedOutput = inputJsonObj.getString("expectedOutput");
				log.add("EXPECTED OUTPUT : " + expectedOutput);
			}
			// default prometheus url
			if (inputJsonObj.has("PROMETHEUS_URL")) {
				prometheusUrl = inputJsonObj.getString("PROMETHEUS_URL");
			} else {
				prometheusUrl = endToEndProperties.getProperty("PROMETHEUSURL");
			}
			// Iterations to execute query
			if (inputJsonObj.has("iteration") && !inputJsonObj.get("iteration").toString().equalsIgnoreCase("NA")) {
				noOfIteration = Integer.parseInt(inputJsonObj.get("iteration").toString());
			}
			// Processing the return value
			if (inputJsonObj.has("returnValue") && !inputJsonObj.get("returnValue").equals("0")) {
				returnValue = new JSONObject(inputJsonObj.get("returnValue").toString());
			}
			if (inputJsonObj.has("site_name")) {
				siteName = inputJsonObj.getString("site_name");
			} else {
				siteName = endToEndProperties.getProperty(vCMTSIP + "~site_name");
			}
			String clusterName = "";
			if (typeOfServer.contains("xi") && inputJsonObj.has("ppod_name")) {
				clusterName = inputJsonObj.getString("ppod_name");
			} else {
				clusterName = endToEndProperties.getProperty(inputJsonObj.getString("cmtsIp") + "~cluster_name");
			}

			List<String> namespaces = new ArrayList<String>();
			if (returnValue.has("namespaceToBeUsed")) {
				namespaces.add(returnValue.getString("namespaceToBeUsed"));
			} else if (inputJsonObj.has("daasSystem") && (inputJsonObj.getString("daasSystem").contains("pa")
					|| inputJsonObj.getString("daasSystem").contains("Random")
					|| inputJsonObj.getString("daasSystem").contains("All"))) {
				String daasSystem = inputJsonObj.getString("daasSystem");
				if (daasSystem.contains("pa")) {
					namespaces.add(daasSystem);
				} else {
					String command = "kubectl get namespaces | grep -i 'pa' | cut -d ' ' -f1";
					if (inputJsonObj.has("EXCLUDE_NAMESPACE")
							&& !inputJsonObj.getString("EXCLUDE_NAMESPACE").contains("NA")) {
						excludeNamespace = inputJsonObj.getString("EXCLUDE_NAMESPACE").replaceAll(",", "|");
						command = command + " | grep -vE '" + excludeNamespace + "'";
					}
					String nodeLocation = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, command,
							"true", endToEndProperties).toString();
					for (String eachnamespace : nodeLocation.split(";")) {
						if (eachnamespace.contains("pa")) {
							namespaces.add(eachnamespace);
						}
					}
					if (SSHFunctionality.getSshObjMap().containsKey(id)
							&& SSHFunctionality.getSshObjMap().get(id).getSshConnectionStatus()) {
						ssh.disconnectSession(id);
					}
				}
			} else {
				namespaces.add(endToEndProperties.getProperty(inputJsonObj.getString("cmtsIp") + "~podNameSpace1"));
			}
			if (excludeSimRPDs.contains("yes")) {
				String site_Name = inputJsonObj.getString("site_name");
				List<String> rpdSimulatorNameList = SnmpUtilityService.getSimulatorRpdMacListWithCluster("rpd_name",
						site_Name, clusterName);
				if (rpdSimulatorNameList.size() > 1) {
					String rpdSimulatorList = rpdSimulatorNameList.toString();
					excludeRPD = excludeRPD
							+ rpdSimulatorList.replace("[", "").replace("]", "").replace(" ", "").replaceAll(",", "|");
				} else if (rpdSimulatorNameList.size() == 1) {
					excludeRPD = excludeRPD + rpdSimulatorNameList.get(0);
				}
			}
			if (!prometheusURLFromDropdown.isEmpty()) {
				finalURL = prometheusUrl + "?" + prometheusURLFromDropdown;
			} else {
				String str = "";
				String filterKey = "";
				StringBuilder sb = new StringBuilder();

				if (!siteName.isEmpty()) {
					str = "site_name=~\"" + siteName + "\"";
					sb.append(str).append(",");
				}
				if (!clusterName.isEmpty()) {
					str = "cluster_name=~\"" + clusterName + "\"";
					sb.append(str).append(",");
				}
				if (!excludeRPD.isEmpty()) {
					str = "rpdName!~\"" + excludeRPD.replaceAll(", ", ",").replaceAll(",", "|") + "\"";
					sb.append(str).append(",");
				}
				if (!excludeNamespace.isEmpty()) {
					str = "namespace!~\"" + excludeNamespace.replaceAll(", ", ",").replaceAll(",", "|") + "\"";
					sb.append(str).append(",");
				}

				for (String eachFilter : prometheusFilter.split(",")) {
					String filter = eachFilter.trim();
					if (returnValue.has(filter)) {
						String returnval[] = returnValue.getString(filter).split(", ");
						if (returnval.length == 1) {
							log.add("Replacing " + filter + " - " + returnValue.getString(filter));
							str = filter + "=" + "~\"" + returnValue.getString(filter) + "\"";
							sb.append(str).append(",");
						} else {
							log.add("Replacing " + filter + " - " + returnValue.getString(filter));
							str = filter + "=" + "~\"" + returnValue.getString(filter).replaceAll(", ", "|") + "\"";
							sb.append(str).append(",");
						}
					} else if (inputKey.contains(filter)) {
						String inputKeys[] = inputKey.split(",");
						String inputValues[] = inputValue.split(",");
						for (int eachkey = 0; eachkey < inputKeys.length; eachkey++) {
							if (inputKeys[eachkey].contains(filter)) {
								log.add("Replacing " + filter + " - " + inputValues[eachkey]);
								str = filter + "=" + "~\"" + inputValues[eachkey] + "\"";
								sb.append(str).append(",");
								break;
							}
						}
					}

				}

				filterKey = sb.deleteCharAt(sb.length() - 1).toString();
				filterKey = URLEncoder.encode(filterKey, "utf-8");
				finalURL = prometheusUrl + "?" + (endToEndProperties.getProperty("PROMETHEUSQUERY")
						.replace("KTOPIC", prometheusMetric).replace("FILTERKEY", filterKey));

			}
			boolean successOutput = false;
			for (int iteration = 1; iteration <= noOfIteration; iteration++) {
				if (inputJsonObj.has("waitTime") && !inputJsonObj.get("waitTime").toString().equalsIgnoreCase("NA")) {
					int sleepTime = Integer.parseInt(inputJsonObj.get("waitTime").toString());
					Thread.sleep(sleepTime * 1000);
					totalWaitTime = totalWaitTime + sleepTime;
					log.add(" WAITING FOR " + sleepTime + " seconds");
				}

				log.add("PROMETHEUS URL : " + finalURL);
				log.add("****** SENDING PROMETHEUS REQUEST *******");

				outputFromPrometheus = executePrometheusQuery(finalURL, system_OS);
				log.add("RESPONSE OBTAINED FROM PROMETHEUS : " + outputFromPrometheus);
				if (!outputFromPrometheus.equalsIgnoreCase("Failure")) {
					JSONObject tempObj = new JSONObject(outputFromPrometheus);
					String data = tempObj.toString(1);
					JSONArray prometheusRes = tempObj.getJSONObject("data").getJSONArray("result");
					if (prometheusRes.length() == 0) {
						log.add("***************************************************************");
						log.add("PROMETHEUS QUERY OUTPUT FROM THE TELEMETRY IS NULL -------FAIL");
						log.add("***************************************************************");
						result = RlcmCommandConstants.RESULT_FAILURE;
					} else {
						if (!matchOutputInPrometheus.isEmpty()) {
							for (String eachMatchData : matchOutputInPrometheus.split(",")) {
								if (data.contains(eachMatchData)) {
									log.add(eachMatchData + " found in the prometheus output");
									result = RlcmCommandConstants.RESULT_SUCCESS;
									successOutput = true;
								}
							}
						}
						Set<String> metricSet = new HashSet<String>();
						String value = "";
						Random r = new Random();
						if (!getDataFromPrometheus.isEmpty()) {
							for (String eachData : getDataFromPrometheus.split(",")) {
								if (eachData.contains("value")) {
									for (int i = 0; i < prometheusRes.length(); i++) {
										String out = prometheusRes.get(i).toString();
										JSONObject objects = new JSONObject(out);
										Pattern p = Pattern.compile("\"([^\"]*)\"");
										Matcher m = p.matcher(objects.get("value").toString());
										if (m.find()) {
											value = m.group(1).trim();
											returnValue.put(eachData, value);
											log.add("VALUE OF " + eachData + " OBTAINED : " + value);
											result = RlcmCommandConstants.RESULT_SUCCESS;
										}
									}
								}

								if (dataNeeded.contains("All") || eachData.contains("list")) {
									eachData = eachData.replace("_list", "");
									for (int i = 0; i < prometheusRes.length(); i++) {
										JSONObject metrics = (JSONObject) prometheusRes.getJSONObject(i).get("metric");
										if (metrics.has(eachData)) {
											value = metrics.get(eachData).toString();
											metricSet.add(value);

										}

									}
									if (!metricSet.isEmpty()) {
										returnValue.put(eachData, metricSet.toString());
										log.add("VALUE OF " + eachData + " OBTAINED : " + metricSet.toString());
										result = RlcmCommandConstants.RESULT_SUCCESS;
									} else {
										result = RlcmCommandConstants.RESULT_FAILURE;
									}
								} else {
									for (int i = 0; i < prometheusRes.length(); i++) {
										int index = r.nextInt(prometheusRes.length());
										JSONObject metrics = (JSONObject) prometheusRes.getJSONObject(index)
												.get("metric");
										if (metrics.has(eachData)) {
											value = metrics.get(eachData).toString();
											returnValue.put(eachData, value);
											log.add("VALUE OF " + eachData + " OBTAINED : " + value);
											result = RlcmCommandConstants.RESULT_SUCCESS;
											break;
										} else {
											result = RlcmCommandConstants.RESULT_FAILURE;
										}
									}
								}

								result = RlcmCommandConstants.RESULT_SUCCESS;

							}
						}
					}
				} else {
					log.add("***************************************************************");
					log.add("PROMETHEUS QUERY OUTPUT FROM THE TELEMETRY IS NULL -------FAIL");
					log.add("***************************************************************");
					result = RlcmCommandConstants.RESULT_FAILURE;
				}
				if (successOutput) {
					break;
				}
			}

		} catch (

		Exception e) {
			log.add(e.getMessage());
			e.printStackTrace();
		}
		return

		returnJson(inputs);
	}

	public String executePrometheusQuery(String url, String systemOS) {
		System.out.println("executePrometheusQuery");
		String output = "";
		String filen = "Prometheus.py";
		try {
			// log.add("Executing the python script : " + filen);
			BufferedReader reader = null;
			BufferedReader stdError = null;
			Process p = null;
			// log.add("******* EXECUTE PYTHON SCRIPT TO FETCH PROMETHEUS OUTPUT
			// **********");
			String value = "";
			String system_OS = System.getProperty("os.name");
			String[] command = null;
			// url = url.replaceAll("\"", "'");
			if (system_OS.contains("Linux") || system_OS.contains("linux")) {
				command = new String[3];
				command[0] = "bash";
				command[1] = "-c";
				String arguments = RlcmCommandConstants.LINUX_PROMETHEUS_PATH + filen + RlcmCommandConstants.SPACE + "'"
						+ url + "'";
				log.add("Excecuting the command :" + arguments);
				command[2] = arguments;
			} else {
				command = new String[3];
				command[0] = "cmd";
				command[1] = "/c";
				String arguments = RlcmCommandConstants.PROMETHEUS_PATH + filen + RlcmCommandConstants.SPACE + "\""
						+ url + "\"";
				log.add("Prometheus URL:" + arguments);
				command[2] = arguments;
			}
			System.out.println(command);
			p = Runtime.getRuntime().exec(command);
			reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

			while ((value = reader.readLine()) != null) {
				output = output + value;
				// log.add(output);
				System.out.println(output);
			}

			reader.close();
			stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			String Error;
			while ((Error = stdError.readLine()) != null) {
				System.out.println(Error);
				output = "failure";
			}
			stdError.close();

			System.out.println("#################################output " + output);
			if (isJSONValid(output)) {
				JSONObject tempObj = new JSONObject(output);
				tempObj.remove("warnings");
				output = tempObj.toString();
			} else if (output.contains("Hit insecure cert") || output.contains("no alert")) {
				System.out.println("inside if");
				log.add("**************************************************************");
				log.add("SESSION ID EXPIRED . INSECURE CERT ERROR FOUND ");
				log.add("**************************************************************");
				output = "failure";
			} else if (output.contains("error") || !output.contains("success")) {
				log.add("**************************************************************");
				log.add("INVALID PROMETHEUS RESPONSE . GETTING ERROR OUTPUT FROM PROMETHEUS ");
				log.add("**************************************************************");
				output = "failure";
			} else if (output.contains("Service Unavailable")) {
				log.add("**************************************************************");
				log.add("PROMETHUS IS DOWN. OUTPUT FROM PROMETHEUS " + output + " . Please try after sometime");
				log.add("**************************************************************");
				output = "failure";
			} else if (!output.contains("value") && !output.contains("success")) {
				log.add("**************************************************************");
				log.add("INVALID PROMETHEUS RESPONSE " + output + " . Please try after sometime");
				log.add("**************************************************************");
				output = "failure";
			} else if (!isJSONValid(output)) {
				// Adding json validator
				log.add("**************************************************************");
				log.add("OBTAINED PROMETHEUS RESPONSE IS NOT A VALID JSON . OBTAINED -->" + output
						+ " . Please try after sometime");
				log.add("**************************************************************");
				output = "failure";
			}
			p.destroy();

		} catch (Exception e) {
			e.printStackTrace();
			catchException(e);
			output = "failure";
		} catch (Error e) {
			e.printStackTrace();
			catchError(e);
			output = "failure";
		}

		return output;
	}

	// JSON validator method
	public static boolean isJSONValid(String jsonInString) {

		try {
			gson.fromJson(jsonInString, Object.class);
			return true;
		} catch (com.google.gson.JsonSyntaxException ex) {
			return false;
		}
	}

	public StringBuilder executeKubeCommand(String vCMTSIP, String vCMTSUsername, String vCMTSPassword,
			SSHFunctionality ssh, String command, String retval, Properties endToEndProperties) {

		ArrayList<String> cmdsToExec = new ArrayList<>();
		String[] lines = null;
		int linesLen = 0;

		String outputStr = "";
		StringBuilder response = new StringBuilder();
		if (retval.contains("false")) {
			log.add("command : " + command);
		}
		JSONObject outputJson = new JSONObject();
		try {
			if (vCMTSIP.contains("%") && vCMTSIP.contains("xi")) {
				String inputs = vCMTSIP.split("%")[2].trim();
				JSONObject inputJsonObj = new JSONObject(inputs);
				String id = vCMTSIP.split("%")[3].trim();
				System.out.println("vCMTSIP" + vCMTSIP);
				vCMTSIP = vCMTSIP.split("%")[0].trim();
				if (SSHFunctionality.getSshObjMap().isEmpty()) {
					System.out.println("map is empty");
				}
				if (!SSHFunctionality.getSshObjMap().containsKey(id)) {
					System.out.println("map does not contain the key id");
				}
				boolean loginSuccess = false;
				if (SSHFunctionality.getSshObjMap().containsKey(id)
						&& SSHFunctionality.getSshObjMap().get(id).getSshConnectionStatus()) {
					outputJson = ssh.executeXiCommand(command, id);
					loginSuccess = true;
				} else {
					// log.add("false");
					ssh.connectXiMaster(inputJsonObj.toString(), vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, id);
					if (SSHFunctionality.getSshObjMap().containsKey(id)
							&& SSHFunctionality.getSshObjMap().get(id).getSshConnectionStatus()) {
						outputJson = ssh.executeXiCommand(command, id);
						loginSuccess = true;
					} else {
						log.add("Could not connect to xi master");
					}
				}
				if (loginSuccess) {
					outputStr = (String) outputJson.get(command);
					if (outputJson.has("ExceptionOccured")) {
						log.add(outputJson.getString("ExceptionOccured"));
					}
					lines = outputStr.split(System.lineSeparator());
					linesLen = outputStr.split(System.lineSeparator()).length;
					System.out.println("Length of Lines1:" + linesLen);
				}
			} else if (vCMTSUsername.contains("SPLIT") && vCMTSUsername.contains("CC")) {
				String inputs = vCMTSUsername.split("SPLIT")[2].trim();
				JSONObject inputJsonObj = new JSONObject(inputs);
				String id = vCMTSUsername.split("SPLIT")[3].trim();
				vCMTSUsername = vCMTSUsername.split("SPLIT")[0].trim();
				if (SSHFunctionality.getSshObjMap().isEmpty()) {
					System.out.println("cc06 map is empty");
				}
				if (!SSHFunctionality.getSshObjMap().containsKey(id)) {
					System.out.println("cc06 map does not contain the key id");
				}
				boolean loginSuccess = false;
				if (SSHFunctionality.getSshObjMap().containsKey(id)
						&& SSHFunctionality.getSshObjMap().get(id).getSshConnectionStatus()) {
					outputJson = ssh.executeCCCommand(command, id);
					loginSuccess = true;
				} else {
					// log.add("false",endToEndProperties);
					ssh.connectCCMaster(inputJsonObj.toString(), vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, id);
					if (SSHFunctionality.getSshObjMap().containsKey(id)
							&& SSHFunctionality.getSshObjMap().get(id).getSshConnectionStatus()) {
						outputJson = ssh.executeCCCommand(command, id);
						loginSuccess = true;
					} else {
						log.add("Could not connect to cc06 master");
						response.append("MASTER_LOGIN_FAILED");
					}
				}
				if (loginSuccess) {
					outputStr = (String) outputJson.get(command);
					if (outputJson.has("ExceptionOccured")) {
						log.add(outputJson.getString("ExceptionOccured"));
					}
					lines = outputStr.split(System.lineSeparator());
					linesLen = outputStr.split(System.lineSeparator()).length;
					System.out.println("Length of Lines1:" + linesLen);
				}
			} else if (endToEndProperties.containsKey(vCMTSIP + "~site_name")
					&& endToEndProperties.getProperty(vCMTSIP + "~site_name").contains("CC")) {
				System.out.println("inside ccprod/cc06");
				cmdsToExec.clear();
				cmdsToExec.add(command);
				outputJson = ssh.connectCCPRODMaster(vCMTSIP, vCMTSUsername, vCMTSPassword, cmdsToExec);
				outputStr = (String) outputJson.get(command);
				lines = outputStr.split(System.lineSeparator());
				linesLen = outputStr.split(System.lineSeparator()).length;
				System.out.println("Length of Lines2:" + linesLen);
			} else if (command.contains("/var/run/ptpd.status")) {
				cmdsToExec.clear();
				cmdsToExec.add(command);
				outputJson = ssh.sendSshCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, cmdsToExec);
				outputStr = (String) outputJson.get("sshOutput");
			} else {
				System.out.println("inside else ;;;;;;;;;;;;;;;;");
				cmdsToExec.clear();
				cmdsToExec.add(command);
				System.out.println(cmdsToExec);

//			if (command.equalsIgnoreCase("kubectl get nodes")) {
//				ssh.setCmdExecDelay(30000);
//			}

				outputJson = new JSONObject();
				if (vCMTSIP.equalsIgnoreCase("96.113.165.2")
						|| endToEndProperties.getProperty(vCMTSIP + "~site_name").contains("BG")) {

					outputJson = ssh.sshMultipleCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, cmdsToExec, "BG");
					outputStr = (String) outputJson.get("sshOutput");
					lines = outputStr.split(System.lineSeparator());
					linesLen = outputStr.split(System.lineSeparator()).length;
					System.out.println("Length of Lines1:" + linesLen);
				} else if (vCMTSIP.contains("CCPROD")) {
					System.out.println("inside ccprod");
					outputJson = ssh.sshProdCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, cmdsToExec, retval);
					outputStr = (String) outputJson.get("sshOutput");
					lines = outputStr.split(";");
					linesLen = outputStr.split(";").length;
					System.out.println("Length of Lines2:" + linesLen);
				} else if (endToEndProperties.getProperty(vCMTSIP + "~site_name").contains("CCPROD")) {
					System.out.println("inside ccprod ip");
					outputJson = ssh.sshProdCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, cmdsToExec, retval);
					outputStr = (String) outputJson.get("sshOutput");
					lines = outputStr.split(";");
					linesLen = outputStr.split(";").length;
					System.out.println("Length of Lines2:" + linesLen);
				}

			}
			System.out.println("Outputstr:" + outputStr);

			/*
			 * String[] lines = outputStr.split(System.lineSeparator()); int linesLen =
			 * outputStr.split(System.lineSeparator()).length;
			 * System.out.println("Length of Lines:"+linesLen); String[] lines =
			 * outputStr.split(";"); int linesLen = outputStr.split(";").length;
			 * System.out.println("Length of Lines:"+linesLen);
			 */
			if (linesLen == 0) {
				log.add("Command execution failed");
			} else if (linesLen > 1) {
				for (int i = 1; i <= linesLen - 1; i++) {

					if (!lines[i].isEmpty()) {
						if (!lines[i].contains("ubuntu") && !lines[i].contains(command)) {
							if (retval.contains("false")) {
								log.add(lines[i].replaceAll("\\u001b\\[94m\\u001b\\[1m   ", "")
										.replaceAll("\\u001b\\[0m   ", "").trim());
							}
							if (!lines[i].equals("")) {

								response.append(lines[i].replaceAll("\\u001b\\[94m\\u001b\\[1m   ", "")
										.replaceAll("\\u001b\\[0m   ", "").trim() + ";");
							}
						}
					}
				}
			} else {
				response.append(
						lines[0].replaceAll("\\u001b\\[94m\\u001b\\[1m   ", "").replaceAll("\\u001b\\[0m", "").trim()
								+ ";");
			}

		} catch (Exception e) {
			log.add("Exception in executing kubectl command " + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("ResponseEXECUTEKUBE:" + response);
		return response;

	}

	// API to execute kubectl commands

	public String sendKubectlCommand(String inputJson) {
		log.add("Venkat inputJson : " + inputJson);
		boolean isSidClust = false;
		String kubeCmdMdInfo = "";
		if (inputJson.contains("SidPoolUtilization"))
			isSidClust = true;
		
		String matchString = "";
		String replaceString = "";
		String propKeyName = "";
		String command = "";
		String returnValueKey = "";
		String output = "";
		String typeOfServer = "";
		SSHFunctionality ssh = new SSHFunctionality();
		String id = "";
		String requiredData = "";
		String dataNeededFor = "";
		String mdType = "";
		String replaceValue = "";
		List<String> namespaces = new ArrayList<String>();
		List<String> pgpods = new ArrayList<String>();
		KubectlService kubectlService = new KubectlService();
		boolean successOutput = false;
		try {

			JSONObject inputJSONobj = new JSONObject(inputJson);
			// expected output from API -description
			if (inputJSONobj.has("expectedOutput") && !inputJSONobj.get("expectedOutput").equals("NA")) {
				String expectedOutput = inputJSONobj.getString("expectedOutput");
				log.add("EXPECTED OUTPUT : " + expectedOutput);
			}
			String vCMTSIP = inputJSONobj.getString("cmtsIp");
			String vCMTSUsername = inputJSONobj.getString("loginUserName");
			String vCMTSPassword = inputJSONobj.getString("loginPassword");
			if (inputJSONobj.has("returnValue") && !inputJSONobj.get("returnValue").equals("0")) {
				returnValue = new JSONObject(inputJSONobj.get("returnValue").toString());
			}
			if (inputJSONobj.has("branch_name") && (inputJSONobj.getString("branch_name").contains("xi")
					|| inputJSONobj.getString("branch_name").contains("pak"))) {
				typeOfServer = "xi";
				Calendar c = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("YYYY_MM_dd_hhmmss_SSS");
				String ddd = sdf.format(c.getTimeInMillis());
				id = inputJSONobj.getString("branch_name") + ddd;
				System.out.println("ssh id  " + id);
				vCMTSIP = vCMTSIP + "%" + "xi" + "%" + inputJSONobj.toString() + "%" + id;
			} else if (endToEndProperties.getProperty(vCMTSIP + "~site_name").contains("CC")) {
				String branchName = endToEndProperties.getProperty(vCMTSIP + "~site_name");
				vCMTSUsername = inputJSONobj.getString("vCMTSIP");
				Calendar c = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("YYYY_MM_dd_hhmmss_SSS");
				String ddd = sdf.format(c.getTimeInMillis());
				id = inputJSONobj.getString("branch_name") + ddd;
				System.out.println("ssh id  " + id);
				vCMTSUsername = vCMTSUsername.replace(vCMTSUsername.split("SPLIT")[3].trim(), id);
			} else if (endToEndProperties.getProperty(vCMTSIP + "~site_name").contains("CCPROD")) {
				vCMTSIP = vCMTSIP + "~" + endToEndProperties.getProperty(vCMTSIP + "~site_name");
			}
			String system_OS = System.getProperty("os.name");

			// exclude namespace
			String excludeNamespace = "";
			if (inputJSONobj.has("EXCLUDE_NAMESPACE") && !inputJSONobj.getString("EXCLUDE_NAMESPACE").contains("NA")) {
				excludeNamespace = inputJSONobj.getString("EXCLUDE_NAMESPACE").replaceAll(",", "|");
			}

			// exclude RPD
			String excludeRPD = "";
			if (inputJSONobj.has("EXCLUDE_RPD") && !inputJSONobj.getString("EXCLUDE_RPD").contains("NA")) {
				excludeRPD = inputJSONobj.getString("EXCLUDE_RPD");
			}

			command = (String) inputJSONobj.get("kubectl_command");

			if (inputJSONobj.has("Match_String") && !inputJSONobj.getString("Match_String").equalsIgnoreCase("NA")) {
				matchString = (String) inputJSONobj.get("Match_String");
				log.add("Strings to be matched in the output : " + matchString);
			}
			if (inputJSONobj.has("Replace_String")
					&& !inputJSONobj.getString("Replace_String").equalsIgnoreCase("NA")) {
				replaceString = (String) inputJSONobj.get("Replace_String");
				log.add("Strings to be replaced in the command : " + replaceString);
			}
			if (inputJSONobj.has("Replace_Value") && !inputJSONobj.getString("Replace_Value").equalsIgnoreCase("NA")) {
				replaceValue = (String) inputJSONobj.get("Replace_Value");
				log.add("Value to be replaced in the command : " + replaceValue);
			}

			if (inputJSONobj.has("PropFile_KeyName")
					&& !inputJSONobj.getString("PropFile_KeyName").equalsIgnoreCase("NA")) {
				propKeyName = (String) inputJSONobj.get("PropFile_KeyName");
				log.add("Strings to be fetched from the properties : " + propKeyName);
			}
			if (inputJSONobj.has("returnValueKey")
					&& !inputJSONobj.getString("returnValueKey").equalsIgnoreCase("NA")) {
				returnValueKey = (String) inputJSONobj.get("returnValueKey");
				log.add("Strings to be fetched from the  : " + returnValueKey);
			}
			// If we need any data from the kubectl command
			if (inputJSONobj.has("requiredData") && !inputJSONobj.getString("requiredData").equalsIgnoreCase("NA")) {
				requiredData = (String) inputJSONobj.get("requiredData");
			}
			String siteName = "";
			if (inputJSONobj.has("site_name")) {
				siteName = inputJSONobj.getString("site_name");
			} else {
				siteName = endToEndProperties.getProperty(vCMTSIP + "~site_name");
			}
			String clusterName = "";
			if (typeOfServer.contains("xi") && inputJSONobj.has("ppod_name")) {
				clusterName = inputJSONobj.getString("ppod_name");
			} else {
				clusterName = endToEndProperties.getProperty(inputJSONobj.getString("cmtsIp") + "~cluster_name");
			}
			String outputStr = "";
			String mdid = "";
			boolean isUtil = true;
			if (replaceString.isEmpty()) {
				String kubectlCmd = command;
				outputStr = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, kubectlCmd, "false",
						endToEndProperties).toString();
			} else {
				if (returnValue.has("namespace")) {
					namespaces.add(returnValue.getString("namespace"));
				} else if (returnValue.has("namespaceToBeUsed")) {
					namespaces.add(returnValue.getString("namespaceToBeUsed"));
				} else if (inputJSONobj.has("daasSystem") && (inputJSONobj.getString("daasSystem").contains("pa")
						|| inputJSONobj.getString("daasSystem").contains("Random")
						|| inputJSONobj.getString("daasSystem").contains("All"))) {
					String daasSystem = inputJSONobj.getString("daasSystem");
					if (daasSystem.contains("pa")) {
						namespaces.add(daasSystem);
					} else {
						String nscommand = "kubectl get namespaces | grep -i 'pa' | cut -d ' ' -f1";
						if (!excludeNamespace.isEmpty()) {
							nscommand = nscommand + " | grep -vE '" + excludeNamespace + "'";
						}
						String nodeLocation = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, nscommand,
								"true", endToEndProperties).toString();
						for (String eachnamespace : nodeLocation.split(";")) {
							if (eachnamespace.contains("pa")) {
								namespaces.add(eachnamespace);
							}
						}
					}
				} else {
					namespaces.add(endToEndProperties.getProperty(inputJSONobj.getString("cmtsIp") + "~podNameSpace1"));
				}
				Collections.shuffle(namespaces);
				String[] replaceStrings = replaceString.split(",");
				String[] replaceValues = replaceValue.split(",");
				String[] returnValueKeys = returnValueKey.split(",");
				String[] matchStrings = matchString.split(",");
				String kubectlCmd = command;
				String mdinfoCommand = "";
				for (String namespace : namespaces) {
					if (kubectlCmd.contains("NAMESPACE")) {
						kubectlCmd = kubectlCmd.replace("NAMESPACE", namespace);
						log.add("Value of namespace obtained : " + namespace);
						returnValue.put("namespace", namespace);
					}
					String podName = "";
					if (command.contains("RPD_MAC") || command.contains("RPD_MAC_WITHOUT_COLON")) {
						if (returnValue.has("rpdMacAddr")) {
							String rpdReturn = returnValue.getString("rpdMacAddr").replace("[", "").replace("]", "");
							for (String eachrpd : rpdReturn.split(",")) {
								String kubeCommand = kubectlCmd;
								String rpdMac = eachrpd.trim();
								if (kubeCommand.contains("RPD_MAC_WITHOUT_COLON")) {
									log.add("REPLACE ....");
									rpdMac = rpdMac.replaceAll(":", "").toLowerCase();
									log.add(rpdMac);
									kubeCommand = kubeCommand.replace("RPD_MAC_WITHOUT_COLON", rpdMac);
								} else if (kubeCommand.equalsIgnoreCase("RPD_MAC")) {
									kubeCommand = kubeCommand.replace("RPD_MAC", rpdMac);
								}

								outputStr = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, kubeCommand,
										"false", endToEndProperties).toString();
							}
						} else {
							log.add("RETURNVALUE DOESNOT HAS RPDMACADDRESS");
						}

					} else {
						if (returnValue.has("rpdMacAddr")) {
							String pg = getPgPodOfTheRpd(inputJSONobj.toString(), returnValue.getString("rpdMacAddr"),
									endToEndProperties, vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, typeOfServer,
									namespace);
							log.add("[" + namespace + "]: Pg pod of RPD : " + returnValue.getString("rpdMacAddr") + "/"
									+ pg);
							podName = pg;
							log.add("namespace : " + namespace + " / podName :" + podName);
						} else if (returnValue.has("podName")) {
							podName = returnValue.getString("podName");
							log.add("namespace : " + namespace + " / podName :" + podName);
						} else if (returnValue.has("podNameToBeUsed")) {
							podName = returnValue.getString("podNameToBeUsed");
							log.add("namespace : " + namespace + " / podName :" + podName);
						} else {
							String pgcommand = "kubectl get pods -n " + namespace + " | grep pg- | cut -d ' ' -f1";
							List<String> excludepgs = new ArrayList<String>();
							if (!excludeRPD.isEmpty()) {
								for (String eachExcludeRpd : excludeRPD.split(",")) {
									String rpdMacAddress = SnmpUtilityService.getRpdMacList("rpd_mac", "rpd_name",
											eachExcludeRpd.trim(), siteName, namespace).replace("[", "")
											.replace("]", "");
									if (!rpdMacAddress.isEmpty()) {
										String eachexcludepg = getPgPodOfTheRpd(inputJSONobj.toString(), rpdMacAddress,
												endToEndProperties, vCMTSIP, vCMTSUsername, vCMTSPassword, ssh,
												typeOfServer, namespace);
										log.add("[" + namespace + "]: Excluding RPD : " + rpdMacAddress + "/"
												+ eachexcludepg);
										excludepgs.add(eachexcludepg);
									}
								}
								if (!excludepgs.isEmpty()) {
									String totalexcludepg = excludepgs.toString().replace("[", "").replace("]", "")
											.replaceAll(", ", "|");
									pgcommand = pgcommand + " | grep -vE '" + totalexcludepg + "'";
									log.add(pgcommand);
								}
							}
							String pgcmd = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, pgcommand,
									"false", endToEndProperties).toString();
							for (String eachpg : pgcmd.split(";")) {
								pgpods.add(eachpg);
							}
							podName = pgpods.get(new Random().nextInt(pgpods.size())).toString();
							log.add("namespace : " + namespace + " / podName :" + podName);
						}

//					Collections.shuffle(pgpods);

						for (int index = 0; index < replaceStrings.length; index++) {
							String repStr = replaceStrings[index];
							if (kubectlCmd.contains(repStr) && !replaceValue.isEmpty()
									&& replaceValues.length > index) {
								log.add("inside replaceValue :" + replaceValues[index]);
								kubectlCmd = kubectlCmd.replace(repStr, replaceValues[index]);
							}

							if (kubectlCmd.contains("PODNAME")) {
								kubectlCmd = kubectlCmd.replace("PODNAME", podName);
								log.add("Value of podName obtained : " + podName);
								returnValue.put("podName", podName);
							}
								
							if (kubectlCmd.contains(repStr) && returnValueKeys.length > index
									&& returnValue.has(returnValueKeys[index])) {
								if (returnValue.getString(returnValueKeys[index]).contains(",")) {
									String listofoutput = returnValue.getString(returnValueKeys[index]).replace("[", "")
											.replace("]", "").replace(" ", "");
									if (returnValueKeys[index].contains("cmMacAddr")) {
										if (repStr.contains("MACADDR_WITH_DOT")) {
											List<String> macAddrDot = new ArrayList<String>();
											for (String macAddress : listofoutput.split(",")) {
												Pattern p = Pattern.compile("([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})");
												Matcher m = p.matcher(macAddress);
												if (m.find()) {
													String cmMAC = m.group().replaceAll(":", "").replaceAll("-", "")
															.toLowerCase();
													cmMAC = cmMAC.replaceAll("(.{4})", "$1\\.").substring(0, 14).trim();
													macAddrDot.add(cmMAC);
												}
											}
											kubectlCmd = kubectlCmd.replace(repStr,
													macAddrDot.toString().replace("[", "").replace("]", "")
															.replace(" ", "").replaceAll(",", "|"));
										} else {
											kubectlCmd = kubectlCmd.replace(repStr, listofoutput.replaceAll(",", "|"));
										}

									} else {
										kubectlCmd = kubectlCmd.replace(repStr,
												returnValue.getString(returnValueKeys[index]).replace("[", "")
														.replace("]", "").replace(" ", "").replaceAll(",", "|"));
									}

								} else {
									if (returnValueKeys[index].contains("cmMacAddr")
											&& repStr.contains("MACADDR_WITH_DOT")) {
										Pattern p = Pattern.compile("([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})");
										Matcher m = p.matcher(returnValue.getString(returnValueKeys[index]));
										if (m.find()) {
											String cmMAC = m.group().replaceAll(":", "").replaceAll("-", "")
													.toLowerCase();
											cmMAC = cmMAC.replaceAll("(.{4})", "$1\\.").substring(0, 14).trim();
											kubectlCmd = kubectlCmd.replace(repStr, cmMAC);
										}
									} else {
										kubectlCmd = kubectlCmd.replace(repStr,
												returnValue.getString(returnValueKeys[index]));
									}
								}
							}
						}
						if (isSidClust) {
							mdinfoCommand = "kubectl exec -it " + podName + " -c mulpi -n " + namespace + " -- ulc-debug mulpi ShowMdInfo";
							log.add("Venkat, ShowMdInfo command: " + mdinfoCommand);
							outputStr = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, mdinfoCommand, "false",
									endToEndProperties).toString();
							log.add("Venkat, output of ShowMdInfo: " + outputStr);
							mdid = outputStr.substring(outputStr.indexOf("=") + 1, outputStr.indexOf(","));
							log.add("Venkat, mdId: " + mdid);
							log.add("Venkat, Original Kube command: " + kubectlCmd);
							kubectlCmd = kubectlCmd + " " + mdid + " | " + "awk " + "{'print $5'}";
							log.add("Venkat, Kube command with mdId: " + kubectlCmd);
						}
						outputStr = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, kubectlCmd, "false",
								endToEndProperties).toString();
					}
					if (isSidClust) {
						String lines[] = outputStr.split("\\r?\\n");
						for (String s: lines) {
							float f = Float.parseFloat(s);
							if (Float.compare(80.0f, f) < 0)
								isUtil = false;
						}
					}

					if (outputStr.contains("Error") || outputStr.contains("ERROR")) {
						result = RlcmCommandConstants.RESULT_FAILURE;
					} else {
						if (!requiredData.isEmpty()) {
							for (String eachRequiredData : requiredData.split(",")) {
								String eachData = eachRequiredData;

								String value = "";
								List<String> outputList = new ArrayList<String>();

								for (String eachLine : outputStr.split(";")) {
									if (eachRequiredData.contains("cmMacAddr")
											&& kubectlService.validateMacAddress(eachLine)) {
										value = kubectlService.getMacAddress(eachLine);
									}
									if (eachRequiredData.contains("ipv6Addr")
											&& kubectlService.validateIPV6Address(eachLine)) {
										value = kubectlService.getIPV6Address(eachLine);
									}
									if (eachRequiredData.contains("ipV4Addr")
											&& kubectlService.validateIPV4Address(eachLine)) {
										value = kubectlService.getIPV6Address(eachLine);
									}
									if (eachRequiredData.contains("list")) {
										eachData = eachRequiredData.replace("_list", "");
										outputList.add(value);
									} else {
										break;
									}
								}
								if (!outputList.isEmpty()) {
									value = outputList.toString();
								}
								if (!value.isEmpty()) {
									returnValue.put(eachData, value);
									log.add("Value of " + eachData + " : " + value);
									successOutput = true;
								}
							}
						}
						if (!matchString.isEmpty()) {
							for (String matchData : matchStrings) {
								if (matchData.contains("cmMacAddrFromReturnValue")) {
									if (returnValue.has("cmMacAddr")) {
										for (String cmmac : returnValue.getString("cmMacAddr").split(",")) {
											String cmMacAddr1 = "";
											String cmMacAddr2 = "";
											Pattern p = Pattern.compile("([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})");
											Matcher m = p.matcher(cmmac.trim());
											if (m.find()) {
												cmMacAddr1 = m.group();
												String cmMAC = m.group().replaceAll(":", "").replaceAll("-", "")
														.toLowerCase();
												cmMacAddr2 = cmMAC.replaceAll("(.{4})", "$1\\.").substring(0, 14)
														.trim();
											}
											p = Pattern.compile("[0-9A-Fa-f]{4}[\\.][0-9A-Fa-f]{4}[\\.][0-9A-Fa-f]{4}");
											m = p.matcher(cmmac.trim());
											if (m.find()) {
												cmMacAddr1 = m.group();
											}
											if (outputStr.contains(cmMacAddr1) || outputStr.contains(cmMacAddr2)) {
												log.add("[" + namespace + "]: " + cmmac
														+ " is present in the command output");
											} else {
												log.add("[" + namespace + "]: " + cmmac
														+ " is not present in the command output");
											}
										}
									}
								} else if (outputStr.contains(matchData)) {
									log.add(matchData + " is present in the command output");
									successOutput = true;
									break;
								}
							}
						}
					}

					if (successOutput) {
						break;
					}

				}
				if (isSidClust && !isUtil) {
					log.add("Venkat, SID utilization is more than 80% for the RPD");
					result = RlcmCommandConstants.RESULT_FAILURE;
					
				}
				else {
				result = RlcmCommandConstants.RESULT_SUCCESS;
				}
			}

		} catch (

		Exception e) {
			e.printStackTrace();
			result = RlcmCommandConstants.RESULT_FAILURE;
			log.add("Error Occurred  : " + e);
		} finally {
			if (SSHFunctionality.getSshObjMap().containsKey(id)
					&& SSHFunctionality.getSshObjMap().get(id).getSshConnectionStatus()) {
				try {
					ssh.disconnectSession(id);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return

		returnJson(inputJson);

	}

	public String getPgPodOfTheRpd(String inputs, String rpdMacAddress, Properties endToEndProperties, String vCMTSIP,
			String vCMTSUsername, String vCMTSPassword, SSHFunctionality ssh, String typeOfServer, String namespace) {
		String pod = "";
		String command = "";
		try {
			List<String> activePodName = new ArrayList<String>();
			String command1 = "kubectl get pods -n " + namespace + " | grep 'pg-' | sed -e \"s/\\ \\ */\\ /g\"";
			StringBuilder resp = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, command1, "true",
					endToEndProperties);
			String[] cdpods = resp.toString().split(";");
			for (String s : cdpods) {
				if (s.contains("Running")) {
					String podName = s.split("\\s+")[0].trim();
					command1 = "kubectl exec -it " + podName + " -cmulpi -n" + namespace
							+ " ulc-debug mulpi ShowLccesTopology | cut -d ':' -f3 | cut -d ']' -f1";
					String state = executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, command1, "true",
							endToEndProperties).toString().replace(";", "");
					if (state.contains("StateActive")) {
						activePodName.add(podName);
					}
				}
			}
			for (int eachPod = 0; eachPod < activePodName.size(); eachPod++) {
				VcmtsService vcmtsService = new VcmtsService();
				String podName = activePodName.get(eachPod);
				command = "kubectl exec -it " + podName + " -cmulpi -n " + namespace
						+ " ulc-debug mulpi ShowLccesTopology | grep -v Lcce | awk -F ' ' {'print $3'} | grep -E '([0-9A-Fa-f]{4}:)' | sed 's/://g'";
				String workLoadIp = vcmtsService.executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, command,
						"true", endToEndProperties).toString().replace(";", "");
				// log.add("[" + rpdMacAddress + "] : workLoadIp " + workLoadIp);
				command = "kubectl get workload workload-" + workLoadIp + " -o json -n " + namespace
						+ " | grep rphyMac | sed 's/\\\"//g' | awk -F ': ' '{print $2}'";
				String rpdMacAddr = vcmtsService.executeKubeCommand(vCMTSIP, vCMTSUsername, vCMTSPassword, ssh, command,
						"true", endToEndProperties).toString().replace(";", "");
				if (rpdMacAddress.equalsIgnoreCase(rpdMacAddr)) {
					pod = podName;
					break;
				}
			}
		} catch (Exception e) {
			log.add(e.getMessage());
		}
		return pod;
	}

}